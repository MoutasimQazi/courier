import { createHash } from "node:crypto";

import { getFirestoreDb } from "../config/firebase.js";
import logger from "../utils/logger.js";

const pendingWrites = new Set();

const sanitizeDocumentId = (value) => {
  const source = String(value || "");
  return createHash("sha256").update(source).digest("hex");
};

class FirebaseService {
  storeInsights(userId, insights) {
    if (insights.length === 0) return;

    const operation = this.#writeInsights(userId, insights)
      .catch((error) => {
        logger.error("Failed to persist email intelligence to Firestore.", error);
      })
      .finally(() => pendingWrites.delete(operation));

    pendingWrites.add(operation);
  }

  async #writeInsights(userId, insights) {
    const db = getFirestoreDb();
    const writes = [];

    for (const insight of insights) {
      const documentId = sanitizeDocumentId(insight.sourceId);
      const collection = insight.data.type === "order" ? "orders" : "subscriptions";
      const reference = db.collection("users").doc(userId).collection(collection).doc(documentId);
      writes.push(reference.set(insight.data));
    }

    await Promise.all(writes);
  }

  async flush() {
    await Promise.allSettled([...pendingWrites]);
  }
}

export default new FirebaseService();
