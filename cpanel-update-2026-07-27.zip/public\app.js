const form = document.querySelector("#fetch-form");
const emailInput = document.querySelector("#email");
const fieldError = document.querySelector("#field-error");
const fetchButton = document.querySelector("#fetch-button");
const buttonLabel = document.querySelector(".button-label");
const copyButton = document.querySelector("#copy-button");
const emptyState = document.querySelector("#empty-state");
const loadingState = document.querySelector("#loading-state");
const errorState = document.querySelector("#error-state");
const jsonOutput = document.querySelector("#json-output");
const jsonCode = jsonOutput.querySelector("code");
const summary = document.querySelector("#summary");
const orderCount = document.querySelector("#order-count");
const subscriptionCount = document.querySelector("#subscription-count");

let latestJson = "";

const setLoading = (loading) => {
  fetchButton.disabled = loading;
  buttonLabel.textContent = loading ? "Fetching…" : "Fetch intelligence";
  loadingState.hidden = !loading;
  if (loading) {
    emptyState.hidden = true;
    errorState.hidden = true;
    jsonOutput.hidden = true;
    summary.hidden = true;
    copyButton.disabled = true;
  }
};

const showError = (message) => {
  errorState.textContent = message;
  errorState.hidden = false;
  emptyState.hidden = true;
  jsonOutput.hidden = true;
  summary.hidden = true;
};

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  fieldError.textContent = "";

  const email = emailInput.value.trim().toLowerCase();
  if (!emailInput.validity.valid || !email) {
    fieldError.textContent = "Enter a valid email address.";
    emailInput.focus();
    return;
  }

  setLoading(true);

  try {
    const response = await fetch("/api/emails/sync?limit=250", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "x-user-id": email,
      },
    });
    const payload = await response.json();

    if (!response.ok || payload.success !== true) {
      throw new Error(payload.message || "Unable to fetch email intelligence.");
    }

    latestJson = JSON.stringify(payload, null, 2);
    jsonCode.textContent = latestJson;
    orderCount.textContent = Array.isArray(payload.orders) ? payload.orders.length : 0;
    subscriptionCount.textContent = Array.isArray(payload.subscriptions) ? payload.subscriptions.length : 0;
    summary.hidden = false;
    jsonOutput.hidden = false;
    copyButton.disabled = false;
  } catch (error) {
    showError(error.message || "Something went wrong. Please try again.");
  } finally {
    setLoading(false);
  }
});

copyButton.addEventListener("click", async () => {
  if (!latestJson) return;
  await navigator.clipboard.writeText(latestJson);
  copyButton.textContent = "Copied";
  window.setTimeout(() => {
    copyButton.textContent = "Copy JSON";
  }, 1400);
});
