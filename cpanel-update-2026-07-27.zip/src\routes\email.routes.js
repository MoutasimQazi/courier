import express from "express";

import {
  getEmails,
  getEmailById,
  syncEmails,
} from "../controllers/email.controller.js";

const router = express.Router();

router.get("/", getEmails);

router.get("/:id", getEmailById);

router.post("/sync", syncEmails);

export default router;