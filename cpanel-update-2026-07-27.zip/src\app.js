import cors from "cors";
import express from "express";
import helmet from "helmet";
import morgan from "morgan";
import { fileURLToPath } from "node:url";
import path from "node:path";

import env from "./config/env.js";
import errorHandler from "./middlewares/error.middleware.js";
import notFound from "./middlewares/notFound.middleware.js";
import emailRoutes from "./routes/email.routes.js";
import logger from "./utils/logger.js";
import { successResponse } from "./utils/response.js";

const app = express();
const publicDirectory = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public");

app.disable("x-powered-by");
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(
  morgan(env.nodeEnv === "production" ? "combined" : "dev", {
    stream: { write: (message) => logger.info(message.trim()) },
  })
);
app.use(express.static(publicDirectory));

app.get("/api/health", (req, res) => {
  return successResponse(res, { status: "ok" }, "Email Parser Backend is running.");
});

app.use("/api/emails", emailRoutes);
app.use(notFound);
app.use(errorHandler);

export default app;
