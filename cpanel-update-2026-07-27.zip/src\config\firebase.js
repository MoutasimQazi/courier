import { applicationDefault, getApps, initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";

import env from "./env.js";

let firestore = null;

export const getFirestoreDb = () => {
  if (firestore) return firestore;

  const app = getApps()[0] ?? initializeApp({
    credential: applicationDefault(),
    ...(env.firebase.projectId ? { projectId: env.firebase.projectId } : {}),
  });

  firestore = getFirestore(app);
  return firestore;
};
