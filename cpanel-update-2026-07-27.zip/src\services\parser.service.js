import { extractEmail } from "../extractors/emailExtractor.js";

class ParserService {
  parse(rawEmail) {
    return extractEmail(rawEmail);
  }
}

export default new ParserService();
