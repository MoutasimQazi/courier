/**
 * emailExtractor.js  —  courier + subscription extraction (NO AI)
 * ------------------------------------------------------------
 * Scope: this parser ONLY cares about two kinds of mail — shipment/courier
 * updates and subscription/billing mail. Every other message (order-only
 * confirmations, marketing, personal mail, receipts with no shipment) is
 * IGNORED: extractEmail() returns `null` so the caller logs nothing for it.
 * That is the "don't log every mail" behaviour — we emit a row only when the
 * mail is actually one of the two categories we track.
 *
 * How relevance is decided: each category is scored from LABELS + number
 * SHAPES + a few negative guards (e.g. "free shipping" is marketing, not a
 * shipment). A mail is emitted only if a category clears a confidence bar.
 * Matching labels, not brands, means an unknown sender still parses correctly.
 *
 * Output schema is FIXED per category. Missing fields are null (or [] for
 * lists). The sub-object for the other category is null.
 */
function extractEmail(raw = {}) {
  const bodyHtml = raw.body || "";
  const text = htmlToText(raw.body_plain || bodyHtml || "");
  const subject = raw.subject || "";
  const hay = `${subject}\n${text}`;
  const lines = hay.split("\n");

  const fromName = raw.from_attendee?.display_name || "";
  const fromEmail = (raw.from_attendee?.identifier || "").toLowerCase();

  const money = grabMoney(hay);
  const courier = scoreCourier(hay, lines, bodyHtml);
  const sub = scoreSubscription(hay, lines, money);

  // Relevance gate. Only courier or subscription mail is emitted; anything
  // below the confidence bar returns null and the caller records nothing.
  const MIN = 3;
  const isCourier = courier.score >= MIN;
  const isSub = sub.score >= MIN;
  if (!isCourier && !isSub) return null;

  // If both clear the bar (e.g. a subscription box that shipped), the higher
  // score wins; a tie favours subscription because billing intent is narrower.
  const category =
    isSub && (!isCourier || sub.score >= courier.score) ? "subscription" : "courier";

  const base = {
    emailId: raw.id ?? null,
    accountId: raw.account_id ?? null,
    providerMessageId: raw.provider_id?.message_id ?? null,
    receivedAt: raw.date ? new Date(raw.date).toISOString() : null,
    category,
    confidence: category === "subscription" ? sub.score : courier.score,
    merchant: cleanMerchant(fromName, fromEmail),
    from: { name: fromName || null, email: fromEmail || null },
    to: mapAttendees(raw.to_attendees),
    subject: subject || null,
    order: {
      orderNumber: grabByLabel(lines, LABELS.order, VALUE.id, courier.tracking),
      amount: money.amount,
      currency: money.currency,
    },
    bodyText: text || null,
  };

  if (category === "courier") {
    return {
      ...base,
      shipping: {
        trackingNumber: courier.tracking,
        trackingUrl: courier.trackingUrl,
        carrier: guessCarrier(courier.tracking, hay, bodyHtml),
        status: courier.status,
        estimatedDelivery: grabDate(lines, LABELS.deliveryDate),
      },
      subscription: null,
    };
  }

  return {
    ...base,
    shipping: null,
    subscription: {
      isSubscription: true,
      renewalDate: sub.renewalDate,
      trialEndsAt: sub.trialEnd,
      amount: money.amount,
      currency: money.currency,
      billingCycle: sub.cycle,
    },
  };
}

/* ----------------------- label dictionaries ----------------------- */
// Multiple phrasings + a few languages. Add rows here to widen coverage —
// no code changes needed. This is the only place "knowledge" lives.
const LABELS = {
  tracking: [
    "tracking\\s*(?:number|no\\.?|id|code)?", "track\\s*(?:your|this)?\\s*(?:package|parcel|order|shipment)?",
    "awb\\s*(?:number|no\\.?)?", "way\\s?bill", "consignment\\s*(?:number|no\\.?)?",
    "shipment\\s*(?:id|number|no\\.?)", "parcel\\s*(?:id|number)",
    "n[uú]mero de seguimiento", "suivi", "sendungsnummer", "codice di tracciamento",
  ],
  order: [
    "order\\s*(?:confirmation\\s*)?(?:number|no\\.?|id|#)", "order", "confirmation\\s*(?:number|no\\.?|#)",
    "reference\\s*(?:number|no\\.?|#)?", "ref\\.?\\s*(?:no\\.?|#)?", "invoice\\s*(?:number|no\\.?|#)",
    "receipt\\s*(?:number|no\\.?|#)", "transaction\\s*(?:id|number)",
    "bestellnummer", "num[eé]ro de commande", "n[uú]mero de pedido", "numero d'ordine",
  ],
  amount: [
    "grand\\s?total", "total\\s*(?:amount|paid|due|charged)?", "amount\\s*(?:paid|due|charged)?",
    "you\\s?(?:paid|were\\s?charged)", "payment", "sub\\s?total", "price",
    "betrag", "montant", "importe", "totale",
  ],
  deliveryDate: [
    "estimated\\s*delivery", "expected\\s*delivery", "arriv\\w*", "deliver(?:y|ed|s)?\\s*(?:by|on|date)?",
    "out for delivery", "scheduled\\s*(?:for|delivery)",
    "livraison", "zustellung", "entrega",
  ],
  renewDate: [
    "renew\\w*", "next\\s*(?:billing|payment|charge)", "auto[- ]?renew\\w*", "expires?\\s*on",
    "billed\\s*(?:again|next)",
    "n[aä]chste\\s?zahlung", "zahlung\\s?am", "prochain\\s?(?:paiement|pr[eé]l[eè]vement)",
    "pr[oó]ximo\\s?(?:pago|cobro)",
  ],
  trialDate: [
    "trial\\s*ends?", "trial\\s*(?:period\\s*)?(?:ends?|expires?)\\s*(?:on)?", "free\\s?trial\\s*(?:until|ends?)",
  ],
  shipHint: [
    "shipp(?:ed|ing)", "dispatch(?:ed)?", "on (?:its|the) way", "in transit", "parcel", "package",
    "courier", "delivery", "en route",
  ],
};

// Value shapes captured after a label
const VALUE = {
  id: "([A-Za-z0-9][A-Za-z0-9\\-\\/]{3,})",   // alphanumeric id, >=4 chars
};

/* ---------------------- category scoring ---------------------- */
// A mail is courier/subscription only if it clears MIN. Scoring keeps weak,
// ambiguous signals (a lone "delivery", a footer "subscription") from being
// enough on their own — a strong signal (tracking, renewal date, …) is needed.

function scoreCourier(hay, lines, bodyHtml) {
  const tracking = grabByLabel(lines, LABELS.tracking, VALUE.id) || grabTrackingByShape(hay);
  const status = grabStatus(hay);
  const trackingUrl = grabTrackingUrl(bodyHtml);
  const hints = countSignals(hay, LABELS.shipHint);

  let score = 0;
  if (tracking) score += 3;              // a real tracking id is decisive
  if (trackingUrl) score += 2;           // a track-your-package link is strong
  if (status && status !== "confirmed") score += 3;  // shipped/in_transit/…
  else if (status === "confirmed") score += 1;       // order confirmed alone is weak
  score += Math.min(hints, 2);           // supporting words, capped

  // Promotional "free shipping / free delivery" is marketing, not a shipment.
  if (/free\s+(?:shipping|delivery)|delivery\s+available|we\s+deliver|shop\s+now|browse\s+/i.test(hay))
    score -= 3;

  return { score, tracking, status, trackingUrl };
}

function scoreSubscription(hay, lines, money) {
  const renewalDate = grabDate(lines, LABELS.renewDate);
  const trialEnd = grabDate(lines, LABELS.trialDate);
  const cycle = grabCycle(hay);
  const autoRenew =
    /auto[- ]?renew|recurring|renews?\s+(?:on|automatically)|will\s+(?:be\s+)?renew|next\s+(?:billing|payment|charge)|billed\s+(?:again|next)/i.test(hay);
  const hasWord = matchesAny(hay, [
    "subscription", "membership", "abonn\\w*", "abo\\b", "mitgliedschaft",
    "suscripci[oó]n", "abonnement",
  ]);

  let score = 0;
  if (renewalDate) score += 3;           // an explicit renewal/next-charge date
  if (autoRenew) score += 3;             // recurring/auto-renew language
  // A cadence only counts when corroborated by billing — otherwise "weekly
  // newsletter" / "monthly digest" would read as a subscription cycle.
  if (cycle && (money.amount != null || renewalDate || autoRenew || trialEnd)) score += 2;
  if (trialEnd) score += 2;              // trial that converts to paid
  if (hasWord) score += 1;               // the word alone (footer noise) is weak
  if (hasWord && money.amount != null) score += 1;  // word + a charged amount

  return { score, renewalDate, trialEnd, cycle };
}

// Count DISTINCT signal phrases that match (not raw occurrences), so repeating
// the same word doesn't inflate confidence.
function countSignals(hay, alts) {
  let n = 0;
  for (const a of alts) if (new RegExp(a, "i").test(hay)) n++;
  return n;
}

// Best-effort carrier name from the tracking shape, domain, or body keywords.
function guessCarrier(tracking, hay, html) {
  const blob = `${hay}\n${html}`;
  const dict = [
    ["UPS", /\bups\b|1Z[A-Z0-9]{16}/i],
    ["FedEx", /fedex/i],
    ["USPS", /usps|united states postal/i],
    ["DHL", /\bdhl\b/i],
    ["Blue Dart", /blue\s?dart/i],
    ["Delhivery", /delhivery/i],
    ["DTDC", /\bdtdc\b/i],
    ["Ekart", /ekart/i],
    ["India Post", /india\s?post|speed\s?post/i],
    ["Amazon Logistics", /amazon\s?logistics|shipped\s+with\s+amazon/i],
    ["Royal Mail", /royal\s?mail/i],
    ["Australia Post", /australia\s?post|auspost/i],
    ["Canada Post", /canada\s?post/i],
  ];
  for (const [name, re] of dict) if (re.test(blob)) return name;
  if (tracking && /^1Z/i.test(tracking)) return "UPS";
  return null;
}

/* --------------------------- extractors --------------------------- */

// Find first value whose label matches. Searches per-line (label & value are
// usually in the same cell/line), then across the whole blob as a fallback.
function grabByLabel(lines, labelAlternatives, valuePattern, exclude = null) {
  const labelRe = "(?:" + labelAlternatives.join("|") + ")";
  const perLine = new RegExp(labelRe + "\\s*[:#\\-]?\\s*" + valuePattern, "i");
  for (const line of lines) {
    const m = line.match(perLine);
    if (m && m[1] && m[1] !== exclude && hasSignal(m[1])) return clean(m[1]);
  }
  // global fallback: label then value within a short gap (handles line breaks)
  const glob = new RegExp(labelRe + "[\\s:#\\-]{0,4}" + valuePattern, "i");
  const g = lines.join(" ").match(glob);
  if (g && g[1] && g[1] !== exclude && hasSignal(g[1])) return clean(g[1]);
  return null;
}

// An order/tracking id should contain at least one digit (skips words like
// "Confirmation", "Number", "Details" that follow a label).
function hasSignal(v) {
  return /\d/.test(v) && !/^(number|no|id|details|confirmation|status|here|now)$/i.test(v);
}
function clean(v) {
  return v.replace(/[.,);:]+$/, "");
}

// Shape-based tracking fallback when no label is present.
function grabTrackingByShape(hay) {
  const shapes = [
    /\b1Z[A-Z0-9]{16}\b/,                 // UPS
    /\b[A-Z]{2}\d{9}[A-Z]{2}\b/,          // universal postal (e.g. ..IN, ..US)
    /\b(?:94|93|92|95)\d{18,20}\b/,       // USPS
    /\b\d{12,22}\b/,                      // long numeric run (FedEx/DHL/most)
  ];
  for (const re of shapes) {
    const m = hay.match(re);
    // avoid grabbing something that is clearly a phone/date/amount context
    if (m && !/(?:phone|call|tel|mobile|\+\d)/i.test(hay.slice(Math.max(0, m.index - 15), m.index)))
      return m[0];
  }
  return null;
}

// Money: a number directly attached to a currency symbol/code, either side.
function grabMoney(hay) {
  const cur = "(?:₹|Rs\\.?|INR|\\$|USD|US\\$|€|EUR|£|GBP|AED|A\\$|AUD|C\\$|CAD|SGD|¥|JPY|CNY)";
  const num = "(\\d[\\d.,]*\\d|\\d)";
  const codeMap = { "₹": "INR", RS: "INR", INR: "INR", $: "USD", USD: "USD", "US$": "USD",
    "€": "EUR", EUR: "EUR", "£": "GBP", GBP: "GBP", AED: "AED", "A$": "AUD", AUD: "AUD",
    "C$": "CAD", CAD: "CAD", SGD: "SGD", "¥": "JPY", JPY: "JPY", CNY: "CNY" };

  // prefer amounts near a total/amount label
  const labelRe = "(?:" + LABELS.amount.join("|") + ")[^\\d₹$€£¥]{0,20}";
  const labelled = hay.match(new RegExp(labelRe + cur + "\\s?" + num, "i"))
    || hay.match(new RegExp(labelRe + num + "\\s?" + cur, "i"));
  const generic = hay.match(new RegExp(cur + "\\s?" + num, "i"))
    || hay.match(new RegExp(num + "\\s?" + cur, "i"));

  const m = labelled || generic;
  if (!m) return { amount: null, currency: null };
  const symbol = (m[0].match(new RegExp(cur, "i")) || [""])[0].toUpperCase().replace(/\./g, "");
  return {
    amount: parseAmount(m[1] || m[2]),
    currency: codeMap[symbol] || codeMap[symbol.replace("US", "")] || null,
  };
}

// Locale-aware: handles "2,499.00" (US), "9,99" (EU decimal comma),
// "1.299,00" (EU thousands). Ambiguous integer-only cases default to US.
function parseAmount(raw) {
  let s = String(raw).trim();
  const hasComma = s.includes(","), hasDot = s.includes(".");
  if (hasComma && hasDot) {
    s = s.lastIndexOf(",") > s.lastIndexOf(".")
      ? s.replace(/\./g, "").replace(",", ".")   // 1.299,00 -> 1299.00
      : s.replace(/,/g, "");                       // 2,499.00 -> 2499.00
  } else if (hasComma) {
    s = /,\d{2}$/.test(s) ? s.replace(",", ".") : s.replace(/,/g, ""); // 9,99 -> 9.99
  }
  const n = parseFloat(s.replace(/\s/g, ""));
  return isNaN(n) ? null : n;
}

function grabDate(lines, labelAlternatives) {
  const labelRe = new RegExp("(?:" + labelAlternatives.join("|") + ")", "i");
  const dateRe =
    /(\d{4}-\d{2}-\d{2}|\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:,?\s+\d{4})?|\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?(?:\s+\d{4})?)/i;
  for (const line of lines) {
    if (labelRe.test(line)) {
      const m = line.match(dateRe);
      if (m) return toISODate(m[1]);
    }
  }
  const near = lines.join(" ").match(new RegExp(labelRe.source + "[^\\n]{0,50}?" + dateRe.source, "i"));
  if (near) { const m = near[0].match(dateRe); if (m) return toISODate(m[1]); }
  return null;
}

function grabStatus(hay) {
  const map = [
    ["delivered", /delivered|has arrived/i],
    ["out_for_delivery", /out for delivery/i],
    ["in_transit", /in transit|on (?:its|the) way|en route|on the move/i],
    ["shipped", /shipp(?:ed|ing)|dispatch(?:ed)?|has shipped/i],
    ["delayed", /delay(?:ed)?|exception|held/i],
    ["confirmed", /order (?:confirmed|placed|received)|confirmation/i],
  ];
  for (const [s, re] of map) if (re.test(hay)) return s;
  return null;
}

function grabCycle(hay) {
  if (/year(?:ly)?|annual(?:ly)?|per year|\/yr\b/i.test(hay)) return "yearly";
  if (/quarter(?:ly)?/i.test(hay)) return "quarterly";
  if (/month(?:ly)?|per month|\/mo\b/i.test(hay)) return "monthly";
  if (/week(?:ly)?|per week/i.test(hay)) return "weekly";
  return null;
}

function grabTrackingUrl(html) {
  const m = String(html).match(/href=["']([^"']*(?:track|tracking|shipment|sendung|suivi)[^"']*)["']/i);
  return m ? m[1] : null;
}

/* ----------------------------- utils ----------------------------- */
function matchesAny(hay, alts) {
  return new RegExp("(?:" + alts.join("|") + ")", "i").test(hay);
}
function htmlToText(input = "") {
  return String(input)
    .replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|tr|li|td|th|h[1-6])>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">").replace(/&#39;|&apos;/gi, "'").replace(/&quot;/gi, '"')
    .replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}
function mapAttendees(list = []) {
  return (list || []).map((a) => ({ name: a?.display_name || null, email: a?.identifier || null }));
}
function cleanMerchant(name, email) {
  if (name && !/no-?reply|auto-?confirm|notification|do-?not-?reply/i.test(name)) return name;
  const d = (email.split("@")[1] || "").split(".")[0];
  return d ? d.charAt(0).toUpperCase() + d.slice(1) : name || null;
}
function toISODate(str) {
  const d = new Date(str);
  return isNaN(d.getTime()) ? str : d.toISOString().slice(0, 10);
}

export { extractEmail };