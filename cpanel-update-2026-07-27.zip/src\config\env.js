import dotenv from "dotenv";

dotenv.config({ quiet: true });

const parsePositiveInteger = (value, fallback) => {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
};

const env = {
  port: parsePositiveInteger(process.env.PORT, 5010),
  nodeEnv: process.env.NODE_ENV || "development",
  unipile: {
    baseUrl: process.env.UNIPILE_BASE_URL?.trim() || "",
    apiKey: process.env.UNIPILE_API_KEY?.trim() || "",
    accountId: process.env.UNIPILE_ACCOUNT_ID?.trim() || "",
    timeout: parsePositiveInteger(process.env.REQUEST_TIMEOUT, 10000),
  },
  firebase: {
    projectId: process.env.FIREBASE_PROJECT_ID?.trim() || "",
  },
};

export default env;
