import unipileClient from "../config/unipile.js";
import env from "../config/env.js";

const createServiceError = (message, statusCode, errors = null) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  error.errors = errors;
  return error;
};

const assertConfiguration = (accountId) => {
  const required = [
    [env.unipile.baseUrl, "UNIPILE_BASE_URL", "Missing Unipile base URL."],
    [env.unipile.apiKey, "UNIPILE_API_KEY", "Missing Unipile API key."],
    [accountId, "accountId", "Missing Unipile account ID."],
  ];

  for (const [value, field, message] of required) {
    if (!value) throw createServiceError(message, 500, { field });
  }
};

const mapUnipileError = (error, fallbackMessage) => {
  if (error.statusCode) return error;

  if (error.code === "ECONNABORTED" || error.code === "ETIMEDOUT") {
    return createServiceError("Unipile request timed out.", 504);
  }

  if (!error.response) {
    return createServiceError("Unable to connect to Unipile.", 503);
  }

  const upstreamStatus = error.response.status;
  const statusCode = upstreamStatus === 404 ? 404 : upstreamStatus >= 500 ? 502 : upstreamStatus;
  const responseData = error.response.data;
  const message = responseData?.message || responseData?.title || fallbackMessage;
  return createServiceError(message, statusCode, responseData ?? null);
};

const validateListResponse = (data) => {
  const items = Array.isArray(data?.items) ? data.items : Array.isArray(data) ? data : null;
  if (!items) throw createServiceError("Unipile returned an invalid email list response.", 502);
  return { items, cursor: data?.cursor ?? null };
};

class UnipileService {
  async getEmails({ accountId = env.unipile.accountId, cursor, limit, after, before } = {}) {
    assertConfiguration(accountId);

    try {
      const response = await unipileClient.get("/emails", {
        params: {
          account_id: accountId,
          ...(cursor ? { cursor } : {}),
          ...(limit ? { limit } : {}),
          ...(after ? { after } : {}),
          ...(before ? { before } : {}),
        },
      });
      return validateListResponse(response.data);
    } catch (error) {
      throw mapUnipileError(error, "Failed to fetch emails from Unipile.");
    }
  }

  async getEmailById(id, accountId = env.unipile.accountId) {
    assertConfiguration(accountId);

    try {
      const response = await unipileClient.get(`/emails/${encodeURIComponent(id)}`, {
        params: { account_id: accountId },
      });

      if (!response.data || typeof response.data !== "object" || Array.isArray(response.data)) {
        throw createServiceError("Unipile returned an invalid email response.", 502);
      }

      return response.data;
    } catch (error) {
      throw mapUnipileError(error, "Failed to fetch email from Unipile.");
    }
  }
}

export default new UnipileService();
