import dotenv from "dotenv";

dotenv.config({ quiet: true });

const parsePositiveInteger = (value, fallback) => {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
};

const env = {
  port: parsePositiveInteger(process.env.PORT, 5010),
  nodeEnv: process.env.NODE_ENV || "development",
  publicBaseUrl: process.env.PUBLIC_BASE_URL?.trim() || "",
  frontendBaseUrl: process.env.FRONTEND_BASE_URL?.trim() || "",
  unipile: {
    baseUrl: process.env.UNIPILE_BASE_URL?.trim() || "",
    apiKey: process.env.UNIPILE_API_KEY?.trim() || "",
    timeout: parsePositiveInteger(process.env.REQUEST_TIMEOUT, 10000),
    callbackSecret: process.env.UNIPILE_CALLBACK_SECRET?.trim() || "",
    webhookSecret: process.env.UNIPILE_WEBHOOK_SECRET?.trim() || "",
  },
  firebase: {
    projectId: process.env.FIREBASE_PROJECT_ID?.trim() || "",
    web: {
      apiKey: process.env.FIREBASE_WEB_API_KEY?.trim() || "",
      authDomain: process.env.FIREBASE_AUTH_DOMAIN?.trim() || "",
      appId: process.env.FIREBASE_APP_ID?.trim() || "",
    },
  },
};

export default env;
