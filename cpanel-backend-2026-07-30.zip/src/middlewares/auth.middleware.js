import { getFirebaseAuth } from "../config/firebase.js";

const unauthorized = (message) => {
  const error = new Error(message);
  error.statusCode = 401;
  error.errors = { field: "authorization" };
  return error;
};

const authenticate = async (req, res, next) => {
  try {
    const authorization = req.headers.authorization || "";
    const [scheme, token] = authorization.split(" ");

    if (scheme !== "Bearer" || !token) {
      throw unauthorized("A Firebase authentication token is required.");
    }

    const decoded = await getFirebaseAuth().verifyIdToken(token);
    req.user = {
      uid: decoded.uid,
      email: decoded.email ?? null,
      name: decoded.name ?? null,
    };

    return next();
  } catch (error) {
    if (error.statusCode === 401) return next(error);
    return next(unauthorized("Your login session is invalid or expired."));
  }
};

export default authenticate;
