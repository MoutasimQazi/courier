import { createHash } from "node:crypto";

import firebaseService from "./firebase.service.js";
import parserService from "./parser.service.js";
import unipileService from "./unipile.service.js";

const EMAIL_HISTORY_DAYS = 30;
const MAX_PAGE_SIZE = 250;

const getHistoryStart = () => new Date(
  Date.now() - EMAIL_HISTORY_DAYS * 24 * 60 * 60 * 1000
).toISOString();

const titleCase = (value) => {
  if (!value) return null;
  return String(value)
    .split(/[\s_]+/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

const getValidationText = (parsed) => {
  const noise = /unsubscribe|email preferences|notification settings|manage (?:your )?(?:email|subscription)|privacy policy|view in browser/i;

  return `${parsed.subject ?? ""}\n${parsed.bodyText ?? ""}`
    .split("\n")
    .filter((line) => !noise.test(line))
    .join("\n");
};

const hasOrderEvidence = (parsed) => {
  const text = getValidationText(parsed);
  const orderIntent = /\b(?:order (?:confirmation|confirmed|placed|received|accepted|number|no\.?|id|#)|thanks for your order|your order|purchase (?:confirmation|receipt)|invoice|payment (?:received|successful))\b/i.test(text);
  const shippingIntent = /\b(?:tracking (?:number|no\.?|id|code)|track your (?:package|parcel|order|shipment)|shipment|shipped|dispatch(?:ed)?|parcel|courier|out for delivery|in transit)\b/i.test(text);
  const orderIdentifier = Boolean(parsed.order?.orderNumber);
  const trackingIdentifier = Boolean(parsed.shipping?.trackingNumber);
  const paymentEvidence = parsed.order?.amount !== null
    && parsed.order?.amount !== undefined
    && Boolean(parsed.order?.currency);

  return (orderIntent && (orderIdentifier || paymentEvidence))
    || (shippingIntent && trackingIdentifier);
};

const hasSubscriptionEvidence = (parsed) => {
  const text = getValidationText(parsed);
  const subscriptionIntent = /\b(?:subscription|membership|paid plan)\b/i.test(text);
  const lifecycleIntent = /\b(?:subscription|membership) (?:started|activated|confirmed|renewed|expires)|\b(?:renewal|renews? on|auto[- ]?renew|next (?:billing|payment|charge)|recurring (?:billing|payment|charge))\b/i.test(text);
  const paymentIntent = /\b(?:payment (?:received|successful|processed)|charged|invoice|receipt|billing)\b/i.test(text);
  const financialEvidence = parsed.subscription?.amount !== null
    && parsed.subscription?.amount !== undefined
    && Boolean(parsed.subscription?.currency);
  const scheduleEvidence = Boolean(parsed.subscription?.billingCycle || parsed.subscription?.renewalDate);

  return lifecycleIntent && (subscriptionIntent || paymentIntent) && (financialEvidence || scheduleEvidence || paymentIntent);
};

const extractPlan = (parsed) => {
  const text = getValidationText(parsed);
  const match = text.match(/\b(basic|standard|premium|plus|pro|business|enterprise|family|individual|student)\s+(?:plan|subscription|membership)\b/i);
  return match ? titleCase(match[0]) : null;
};

const stableSourceId = (rawEmail) => {
  if (rawEmail.id) return String(rawEmail.id);

  return createHash("sha256")
    .update(JSON.stringify({
      accountId: rawEmail.account_id ?? null,
      providerId: rawEmail.provider_id ?? null,
      date: rawEmail.date ?? null,
      subject: rawEmail.subject ?? null,
    }))
    .digest("hex");
};

const toOrder = (parsed) => ({
  type: "order",
  merchant: parsed.merchant ?? null,
  orderId: parsed.order?.orderNumber ?? null,
  trackingId: parsed.shipping?.trackingNumber ?? null,
  amount: parsed.order?.amount ?? null,
  currency: parsed.order?.currency ?? null,
  status: titleCase(parsed.shipping?.status),
  deliveryDate: parsed.shipping?.estimatedDelivery ?? null,
  items: [],
});

const toSubscription = (parsed) => ({
  type: "subscription",
  merchant: parsed.merchant ?? null,
  plan: extractPlan(parsed),
  amount: parsed.subscription?.amount ?? null,
  currency: parsed.subscription?.currency ?? null,
  billingCycle: parsed.subscription?.billingCycle ?? null,
  renewalDate: parsed.subscription?.renewalDate ?? null,
});

export const transformEmail = (rawEmail) => {
  const parsed = parserService.parse(rawEmail);

  if (!parsed || typeof parsed !== "object") {
    return null;
  }

  const sourceId = stableSourceId(rawEmail);

  if (parsed.category === "subscription" && hasSubscriptionEvidence(parsed)) {
    return { sourceId, data: toSubscription(parsed) };
  }

  if ((parsed.category === "order" || parsed.category === "courier") && hasOrderEvidence(parsed)) {
    return { sourceId, data: toOrder(parsed) };
  }

  return null;
};

const groupInsights = (insights) => ({
  orders: insights.filter(({ data }) => data.type === "order").map(({ data }) => data),
  subscriptions: insights.filter(({ data }) => data.type === "subscription").map(({ data }) => data),
});

class EmailService {
  async #getAccountInsights({ accountId, cursor, limit } = {}) {
    const items = [];
    const seenEmailIds = new Set();
    const after = getHistoryStart();
    const pageSize = limit ?? MAX_PAGE_SIZE;
    let nextCursor = cursor;

    do {
      const result = await unipileService.getEmails({
        accountId,
        cursor: nextCursor,
        limit: pageSize,
        after,
      });

      for (const item of result.items) {
        const id = stableSourceId(item);
        if (!seenEmailIds.has(id)) {
          seenEmailIds.add(id);
          items.push(item);
        }
      }

      nextCursor = result.cursor;
    } while (nextCursor);

    const insights = items.map(transformEmail).filter(Boolean);

    return {
      insights,
      cursor: null,
    };
  }

  async getEmails({ userId, cursor, limit } = {}) {
    const accounts = await firebaseService.getConnectedAccounts(userId);
    if (accounts.length === 0) {
      const error = new Error("Connect a mailbox before fetching email intelligence.");
      error.statusCode = 409;
      error.errors = { field: "connectedAccount" };
      throw error;
    }

    const results = await Promise.all(accounts.map((account) => {
      return this.#getAccountInsights({
        accountId: account.accountId,
        cursor,
        limit,
      });
    }));
    const insights = results.flatMap((result) => result.insights);

    firebaseService.storeInsights(userId, insights);

    return {
      ...groupInsights(insights),
      cursor: null,
    };
  }

  async getEmailById({ id, userId }) {
    const accounts = await firebaseService.getConnectedAccounts(userId);
    if (accounts.length === 0) {
      const error = new Error("Connect a mailbox before requesting email intelligence.");
      error.statusCode = 409;
      error.errors = { field: "connectedAccount" };
      throw error;
    }

    let rawEmail = null;
    for (const account of accounts) {
      try {
        rawEmail = await unipileService.getEmailById(id, account.accountId);
        break;
      } catch (error) {
        if (error.statusCode !== 404) throw error;
      }
    }

    if (!rawEmail) {
      const error = new Error("Email not found in the authenticated user's mailboxes.");
      error.statusCode = 404;
      throw error;
    }

    const insight = transformEmail(rawEmail);
    const insights = insight ? [insight] : [];

    firebaseService.storeInsights(userId, insights);

    return groupInsights(insights);
  }

  async syncEmails(options = {}) {
    return this.getEmails(options);
  }

  async processWebhookEmail(payload) {
    if (payload?.event !== "mail_received") {
      return { processed: false, reason: "event_ignored" };
    }

    const accountId = typeof payload.account_id === "string"
      ? payload.account_id.trim()
      : "";
    const emailId = typeof payload.email_id === "string"
      ? payload.email_id.trim()
      : "";

    if (!accountId || !emailId) {
      const error = new Error("The Unipile email webhook is missing account_id or email_id.");
      error.statusCode = 400;
      error.errors = { fields: ["account_id", "email_id"] };
      throw error;
    }

    const userId = await firebaseService.findUserIdByAccountId(accountId);
    if (!userId) {
      return { processed: false, reason: "account_not_mapped" };
    }

    const rawEmail = await unipileService.getEmailById(emailId, accountId);
    const insight = transformEmail(rawEmail);
    if (!insight) {
      return { processed: false, reason: "not_order_or_subscription" };
    }

    await firebaseService.storeInsights(userId, [insight]);
    return {
      processed: true,
      type: insight.data.type,
    };
  }
}

export default new EmailService();
