import { createHash } from "node:crypto";

import { getFirestoreDb } from "../config/firebase.js";
import logger from "../utils/logger.js";

const pendingWrites = new Set();

const sanitizeDocumentId = (value) => {
  const source = String(value || "");
  return createHash("sha256").update(source).digest("hex");
};

class FirebaseService {
  async ensureUser(user) {
    const db = getFirestoreDb();
    await db.collection("users").doc(user.uid).set({
      email: user.email ?? null,
      name: user.name ?? null,
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  }

  async storeConnectedAccount(userId, account) {
    const db = getFirestoreDb();
    const documentId = sanitizeDocumentId(account.accountId);
    const reference = db
      .collection("users")
      .doc(userId)
      .collection("connectedAccounts")
      .doc(documentId);

    await reference.set({
      accountId: account.accountId,
      provider: account.provider ?? null,
      status: account.status ?? "connected",
      connectedAt: account.connectedAt ?? new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  }

  async deleteConnectedAccount(userId, accountId) {
    const db = getFirestoreDb();
    const documentId = sanitizeDocumentId(accountId);
    await db
      .collection("users")
      .doc(userId)
      .collection("connectedAccounts")
      .doc(documentId)
      .delete();
  }

  async getConnectedAccounts(userId) {
    const db = getFirestoreDb();
    const snapshot = await db
      .collection("users")
      .doc(userId)
      .collection("connectedAccounts")
      .get();

    return snapshot.docs.map((document) => document.data());
  }

  async userOwnsAccount(userId, accountId) {
    const accounts = await this.getConnectedAccounts(userId);
    return accounts.some((account) => account.accountId === accountId);
  }

  async findUserIdByAccountId(accountId) {
    const db = getFirestoreDb();
    const snapshot = await db
      .collectionGroup("connectedAccounts")
      .where("accountId", "==", accountId)
      .limit(1)
      .get();

    if (snapshot.empty) return null;
    return snapshot.docs[0].ref.parent.parent?.id ?? null;
  }

  async updateConnectedAccountStatus(userId, accountId, status) {
    const db = getFirestoreDb();
    const documentId = sanitizeDocumentId(accountId);
    await db
      .collection("users")
      .doc(userId)
      .collection("connectedAccounts")
      .doc(documentId)
      .set({
        status,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
  }

  storeInsights(userId, insights) {
    if (insights.length === 0) return Promise.resolve();

    const operation = this.#writeInsights(userId, insights)
      .catch((error) => {
        logger.error("Failed to persist email intelligence to Firestore.", error);
      })
      .finally(() => pendingWrites.delete(operation));

    pendingWrites.add(operation);
    return operation;
  }

  async #writeInsights(userId, insights) {
    const db = getFirestoreDb();
    const writes = [];

    for (const insight of insights) {
      const documentId = sanitizeDocumentId(insight.sourceId);
      const collection = insight.data.type === "order" ? "orders" : "subscriptions";
      const reference = db.collection("users").doc(userId).collection(collection).doc(documentId);
      writes.push(reference.set(insight.data));
    }

    await Promise.all(writes);
  }

  async flush() {
    await Promise.allSettled([...pendingWrites]);
  }
}

export default new FirebaseService();
