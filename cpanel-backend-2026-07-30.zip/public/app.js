import { initializeApp } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signInAnonymously,
  signOut,
} from "https://www.gstatic.com/firebasejs/12.16.0/firebase-auth.js";

const appView = document.querySelector("#app-view");
const signOutButton = document.querySelector("#sign-out-button");
const signedInEmail = document.querySelector("#signed-in-email");
const accountList = document.querySelector("#account-list");
const connectionMessage = document.querySelector("#connection-message");
const connectButton = document.querySelector("#connect-button");
const fetchButton = document.querySelector("#fetch-button");
const buttonLabel = document.querySelector(".button-label");
const copyButton = document.querySelector("#copy-button");
const emptyState = document.querySelector("#empty-state");
const loadingState = document.querySelector("#loading-state");
const errorState = document.querySelector("#error-state");
const jsonOutput = document.querySelector("#json-output");
const jsonCode = jsonOutput.querySelector("code");
const summary = document.querySelector("#summary");
const orderCount = document.querySelector("#order-count");
const subscriptionCount = document.querySelector("#subscription-count");

let auth;
let currentUser = null;
let latestJson = "";
let connectedAccounts = [];

const getIdToken = async () => {
  if (!currentUser) throw new Error("Preparing your private session. Please try again.");
  return currentUser.getIdToken();
};

const apiRequest = async (url, options = {}) => {
  const token = await getIdToken();
  const response = await fetch(url, {
    ...options,
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${token}`,
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(options.headers || {}),
    },
  });
  const payload = await response.json();
  if (!response.ok || payload.success !== true) {
    throw new Error(payload.message || "The request failed.");
  }
  return payload;
};

const setLoading = (loading) => {
  fetchButton.disabled = loading || connectedAccounts.length === 0;
  connectButton.disabled = loading;
  buttonLabel.textContent = loading ? "Fetching…" : "Fetch intelligence";
  loadingState.hidden = !loading;
  if (loading) {
    emptyState.hidden = true;
    errorState.hidden = true;
    jsonOutput.hidden = true;
    summary.hidden = true;
    copyButton.disabled = true;
  }
};

const showError = (message) => {
  errorState.textContent = message;
  errorState.hidden = false;
  emptyState.hidden = true;
  jsonOutput.hidden = true;
  summary.hidden = true;
};

const renderAccounts = () => {
  accountList.replaceChildren();

  if (connectedAccounts.length === 0) {
    const empty = document.createElement("p");
    empty.className = "account-empty";
    empty.textContent = "No mailbox connected yet.";
    accountList.append(empty);
    fetchButton.disabled = true;
    return;
  }

  for (const account of connectedAccounts) {
    const row = document.createElement("div");
    row.className = "account-row";

    const marker = document.createElement("span");
    marker.className = "account-marker";
    marker.textContent = "✓";

    const details = document.createElement("div");
    const title = document.createElement("strong");
    title.textContent = account.provider || "Email mailbox";
    const subtitle = document.createElement("small");
    subtitle.textContent = account.status || "connected";
    details.append(title, subtitle);

    row.append(marker, details);
    accountList.append(row);
  }

  fetchButton.disabled = false;
};

const loadAccounts = async () => {
  const payload = await apiRequest("/api/accounts");
  connectedAccounts = Array.isArray(payload.data) ? payload.data : [];
  renderAccounts();
  return connectedAccounts;
};

const handleConnectionReturn = async () => {
  const state = new URLSearchParams(window.location.search).get("connection");
  if (!state) return;

  window.history.replaceState({}, "", window.location.pathname);
  connectionMessage.textContent = state === "success"
    ? "Mailbox authenticated. Finishing the connection…"
    : "Mailbox connection was not completed.";

  if (state !== "success") return;

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const accounts = await loadAccounts();
    if (accounts.length > 0) {
      connectionMessage.textContent = "Mailbox connected successfully.";
      return;
    }
    await new Promise((resolve) => window.setTimeout(resolve, 1500));
  }

  connectionMessage.textContent = "Authentication completed, but the callback is still pending. Refresh shortly.";
};

const initialize = async () => {
  try {
    const response = await fetch("/api/config", { headers: { Accept: "application/json" } });
    const payload = await response.json();
    const config = payload?.data?.firebase;

    if (!response.ok || !config?.apiKey || !config?.authDomain || !config?.projectId || !config?.appId) {
      throw new Error("Firebase web configuration is incomplete.");
    }

    auth = getAuth(initializeApp(config));
    onAuthStateChanged(auth, async (user) => {
      if (!user) {
        appView.hidden = true;
        try {
          await signInAnonymously(auth);
        } catch (error) {
          appView.hidden = false;
          connectionMessage.textContent = error.message || "Unable to start a private session.";
        }
        return;
      }

      currentUser = user;
      appView.hidden = false;
      signedInEmail.textContent = "Private session ready";
      connectionMessage.textContent = "";

      try {
        await loadAccounts();
        await handleConnectionReturn();
      } catch (error) {
        connectionMessage.textContent = error.message;
      }
    });
  } catch (error) {
    appView.hidden = false;
    connectionMessage.textContent = error.message;
  }
};

signOutButton.addEventListener("click", async () => {
  await signOut(auth);
  connectedAccounts = [];
  renderAccounts();
});

connectButton.addEventListener("click", async () => {
  connectionMessage.textContent = "";
  connectButton.disabled = true;
  try {
    const payload = await apiRequest("/api/accounts/connect", { method: "POST" });
    window.location.assign(payload.data.url);
  } catch (error) {
    connectionMessage.textContent = error.message;
    connectButton.disabled = false;
  }
});

fetchButton.addEventListener("click", async () => {
  setLoading(true);
  try {
    const payload = await apiRequest("/api/emails/sync?limit=250", { method: "POST" });
    latestJson = JSON.stringify(payload, null, 2);
    jsonCode.textContent = latestJson;
    orderCount.textContent = Array.isArray(payload.orders) ? payload.orders.length : 0;
    subscriptionCount.textContent = Array.isArray(payload.subscriptions) ? payload.subscriptions.length : 0;
    summary.hidden = false;
    jsonOutput.hidden = false;
    copyButton.disabled = false;
  } catch (error) {
    showError(error.message);
  } finally {
    setLoading(false);
  }
});

copyButton.addEventListener("click", async () => {
  if (!latestJson) return;
  await navigator.clipboard.writeText(latestJson);
  copyButton.textContent = "Copied";
  window.setTimeout(() => {
    copyButton.textContent = "Copy JSON";
  }, 1400);
});

initialize();
